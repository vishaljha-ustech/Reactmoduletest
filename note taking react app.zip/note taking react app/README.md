# Note Taking React App
- Run locally
- npm install
- npm run dev